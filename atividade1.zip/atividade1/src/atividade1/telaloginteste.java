/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package atividade1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author 0081376
 */
public interface telaloginteste {
  public class LoginComBanco {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login com Banco de Dados");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setLayout(new FlowLayout());

        JTextField campoUsuario = new JTextField(15);
        JPasswordField campoSenha = new JPasswordField(15);
        JButton botaoLogin = new JButton("Entrar");

        frame.add(new JLabel("Usuário:"));
        frame.add(campoUsuario);
        frame.add(new JLabel("Senha:"));
        frame.add(campoSenha);
        frame.add(botaoLogin);

        botaoLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());

                if (verificarLogin(usuario, senha)) {
                    JOptionPane.showMessageDialog(frame,
                            "Login bem-sucedido!",
                            "Sucesso",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame,
                            "Usuário e/ou senha inválidos.",
                            "Erro de Login",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Método que verifica no banco
    public static boolean verificarLogin(String usuario, String senha) {
        String url = "jdbc:mysql://localhost:3306/exemplo_login";
        String usuarioBD = "root"; // seu usuário do banco
        String senhaBD = "";       // sua senha do banco

        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";

        try (Connection conn = DriverManager.getConnection(url, usuarioBD, senhaBD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            return rs.next(); // true se encontrou usuário

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
  
}


